sed -i 's/\t/_/' *.txt.normalized && for i in $(find . -name "*JG*");do Rscript cal.R $i;done
