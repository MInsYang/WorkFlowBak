use autodie;
open IN,"$ARGV[0]";
while(<IN>){
   if(/G18P/){next;}
   if($_=~/(.*) testing for/){print "$1\t";}
   if($_=~/CIN Score:\(cut off 865\) (\d+)/){print "$1\n";}
   
}
