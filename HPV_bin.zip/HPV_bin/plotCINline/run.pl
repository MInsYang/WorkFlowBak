#use autodie;
print <DATA> if @ARGV!=1;
system("perl ResultFmt.pl $ARGV[0]>$ARGV[0].fmt");
open IN,"$ARGV[0].fmt";
system("rm -rf $ARGV[0].line");
while(<IN>){
   chomp;
   @list=split/\t/;
   open OUT,">$list[0].rscript";
   print OUT "
      c<-read.table(\"cin.txt\",header=T,row.names=1)
      d<-read.table(\"control.txt\",header=T,row.names=1)
      all<-rbind(c,d)
      color<-rainbow(7,alpha=0.5)
      lincolor<-rainbow(7,alpha=1)
      bg=hist(all\$V1,breaks=30,plot=F)
      control=hist(c\$V1,breaks=30,plot=F)
      cin2=hist(d\$V1,breaks=30,plot=F)
      png(\"$list[0].png\",width=1000,height=600,type=\"cairo\")
      par(oma=c(1,1,1,1))
      plot(bg,col=\"white\",freq=F,border=\"white\",ylim=c(0,0.01),xlim=c(400,1200),main=\"Probability Fit\",xlab=\"CINScore\")
      wd<-(min(d\$V1)-2):(max(d\$V1)+2)
      lines(wd,dnorm(wd,mean(d\$V1),sd(d\$V1)),col=lincolor[6],lwd=3)
      wc<-(min(c\$V1)-2):(max(c\$V1)+2)
      lines(wc,dnorm(wc,mean(c\$V1),sd(c\$V1)),col=lincolor[1],lwd=3)
      legend(\"topleft\",c(\"CIN2&3\",\"CIN1&Control\"),col=c(lincolor[1],lincolor[6]),
      text.col=c(lincolor[1],lincolor[6]),lty=c(1,1),lwd=2,bty=\"n\")
      segments($list[1],0,$list[1],0.0095,lwd=3,col=\"green3\")
      dev.off()
   ";
   system("Rscript $list[0].rscript");
}
system("rm -f *.rscript");
system("mkdir $ARGV[0].line && mv *.png $ARGV[0].line");
__DATA__
perl JGprob.pl <SR result>
