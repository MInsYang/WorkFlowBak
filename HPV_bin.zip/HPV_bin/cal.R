op<-commandArgs(T)
q22<-read.table("2_q22.bin",header=F)
p24<-read.table("3_p24.bin",header=F)
q11<-read.table("3_q11.bin",header=F)
p15<-read.table("5_p15.bin",header=F)
p12<-read.table("6_p12.bin",header=F)
q23<-read.table("8_q23.bin",header=F)
q24<-read.table("8_q24.bin",header=F)
q26<-read.table("3_q26.bin",header=F)

data<-read.table(op[1],header=F,row.names=1,sep="\t")
cat(op[1])
cat("\t")
cat("3q26:")
sdata<-data[which(rownames(data) %in% q26$V1),]
cat(mean(sdata))
cat("\t")
cat("2q22:")
sdata<-data[which(rownames(data) %in% q22$V1),]
cat(mean(sdata))
cat("\t")
cat("3p24:")
sdata<-data[which(rownames(data) %in% p24$V1),]
cat(mean(sdata))
cat("\t")
cat("3q11:")
sdata<-data[which(rownames(data) %in% q11$V1),]
cat(mean(sdata))
cat("\t")
cat("8q24:")
sdata<-data[which(rownames(data) %in% q24$V1),]
cat(mean(sdata))
cat("\t")
cat("5p15:")
sdata<-data[which(rownames(data) %in% p15$V1),]
cat(mean(sdata))
cat("\t")
cat("8q23:")
sdata<-data[which(rownames(data) %in% q23$V1),]
cat(mean(sdata))
cat("\t")
cat("6p12:")
sdata<-data[which(rownames(data) %in% p12$V1),]
cat(mean(sdata))
cat("\t")
cat("\n")
